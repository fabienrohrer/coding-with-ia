# INSTALLATION GUIDE FOR MACOS

## Homebrew

```bash
# Is brew installed?
brew --version
# Homebrew 5.0.12

# Install brew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Update brew
brew update 

# Upgrade installed packages
brew upgrade

# Install dependencies
brew install git openjdk node maven
brew install temurin@25

# Complete OpenJDK setup
sudo ln -sfn /usr/local/opt/openjdk/libexec/openjdk.jdk /Library/Java/JavaVirtualMachines/openjdk.jdk
echo 'export PATH="/usr/local/opt/openjdk/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc

# Verify installations
git --version
# git version 2.52.0
java -version
# openjdk version "25.0.2" 2026-01-20
node --version
# v20.18.3
mvn --version
# Apache Maven 3.9.12
```

## Install Docker Desktop

- Download and install Docker Desktop from the [official website](https://www.docker.com/products/docker-desktop/).
- Launch Docker Desktop from Applications.

```bash
echo 'export PATH="/Applications/Docker.app/Contents/Resources/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc

# Verify the installation
docker --version
# Docker version 29.1.3
```

## IntelliJ IDEA and GitHub Copilot Plugin

### Install IntelliJ IDEA

- Download and install JetBrains Toolbox App from the [official website](https://www.jetbrains.com/toolbox-app/).
- From the Toolbox App, install IntelliJ IDEA.

### Install GitHub Copilot Plugin

- Open IntelliJ IDEA
- Go to IntelliJ IDEA > Settings... > Plugins.
- Search for "GitHub Copilot - Your AI Pair Programmer" in the Marketplace tab.
- Install it by clicking the Install button / Restart the IDE.
- In th GitHub Copilot chat window, click Sign in to GitHub and follow the authentication steps.

### Setup maven path

- Go to IntelliJ IDEA > Settings... > "Build, Execution, Deployment" > Build Tools > Maven
- Set "Maven home path" to: "/usr/local/Cellar/maven/3.9.12/libexec"
