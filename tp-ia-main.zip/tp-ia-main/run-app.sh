#!/bin/bash

# Load environment variables from .env file
if [ -f .env ]; then
  set -a
  . ./.env
  set +a
fi

# Navigate to the app directory and run Spring Boot
cd movielist-app
mvn spring-boot:run
