# GETTING STARTED GUIDE

Once installation is complete (see `INSTALL.md`), follow these steps to launch the movielist project.

## 1. Launch PostgreSQL with Docker Compose

From the project root, start the PostgreSQL database:

```bash
# Start the services (PostgreSQL + Adminer)
docker compose up -d

# Verify that containers are running
docker ps
```

You should see two active containers: `tp-ia-postgres-1` and `tp-ia-adminer-1`.

### PostgreSQL Connection Details

The PostgreSQL password is **hardcoded** in the following locations:

1. **Docker Compose configuration** (`compose.yaml`):
   ```yaml
   environment:
       POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
   ```
   The password defaults to: `myPassword` (see `movielist-app/src/main/resources/config/application-default.yaml`)

2. **Spring Boot configuration** (`movielist-app/src/main/resources/config/application-default.yaml`):
   ```yaml
   spring:
     datasource:
       password: ${POSTGRES_PASSWORD:myPassword}
   ```
   The default value is `myPassword`. This can be overridden by setting the `POSTGRES_PASSWORD` environment variable.

### Verify PostgreSQL with Adminer

- Open your browser and go to: **http://localhost:8082**
- You should see the adminer login page.
- Server: `postgres`
- User: `postgres`
- Password: `myPassword`
- Database: (leave empty)

## 2. Build and Launch the Spring Boot Backend

### Setup Maven

- Go to the Maven panel (tab on the right side of IntelliJ IDEA)
- Click on "Add Maven Projects"
- Select the `movielist-app/pom.xml` file

### Build the Maven Project

From the project root:

```bash
# Clean and compile
mvn clean install

# Or if you just want to compile (skip tests)
mvn clean install -DskipTests
```

Wait for the build to complete (a few minutes).

### Launch the Spring Boot Application

```bash

cd movielist-app
mvn spring-boot:run
```

or:

```bash
./run-app.sh
```

### Verify the Backend is Running

Once started, the application should be accessible at:

```
http://localhost:8080
```

## 3. Launch the Angular Frontend

### Install npm Dependencies (first time only)

```bash
cd movielist-web-client
npm install
```

### Start the Angular Development Server

```bash
npm run start
```

The frontend should automatically open at:

```
http://localhost:4200
```

You should see the application home page.

## 4. Install GitHub Copilot

- Install the GitHub Copilot plugin from IntelliJ Marketplace.
- Log in with your GitHub account.

