package ch.movielist.process;

import ch.movielist.config.MovielistUnitTest;
import ch.movielist.domain.model.SampleCountry;
import ch.movielist.domain.repository.SampleCountryRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.assertEquals;

@MovielistUnitTest
class SampleCountryServiceTest {
    private static final String COUNTRY_NAME = "Switzerland";

    @Autowired
    private SampleCountryService sampleCountryService;

    @Autowired
    private SampleCountryRepository sampleCountryRepository;

    @Test
    void createCountry() {
        // Given
        SampleCountry switzerland = new SampleCountry();
        switzerland.setName(COUNTRY_NAME);

        // When
        sampleCountryService.save(switzerland);

        // Then
        assertEquals(1, sampleCountryRepository.findAll().size(), "Should find the country we created");
        assertEquals(COUNTRY_NAME, sampleCountryRepository.findAll().get(0).getName(), "It should be the one we created");
    }
}
