package ch.movielist;

import ch.movielist.config.MovielistUnitTest;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@MovielistUnitTest
@SpringBootTest
class MovielistApplicationTests {

	@Test
    void contextLoads() {
    	// The spring context loads.
    }

}
