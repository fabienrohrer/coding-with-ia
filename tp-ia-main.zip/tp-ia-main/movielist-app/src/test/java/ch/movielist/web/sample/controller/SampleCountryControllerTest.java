package ch.movielist.web.sample.controller;

import ch.movielist.config.MovielistUnitTest;
import ch.movielist.domain.model.SampleCountry;
import ch.movielist.domain.repository.SampleCountryRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.nio.charset.StandardCharsets;

import static ch.movielist.web.sample.SampleContext.SAMPLE_PATH;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsArrayWithSize.arrayWithSize;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@MovielistUnitTest
@AutoConfigureMockMvc
@WithMockUser(username = "GUEST", authorities = {"SCOPE_GUEST"})
@Slf4j
class SampleCountryControllerTest {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private SampleCountryRepository sampleCountryRepository;
    MockHttpSession session = new MockHttpSession();

    @BeforeEach
    void beforeEach() {
        sampleCountryRepository.deleteAll();
    }

    @Test
    void testOneCountry() throws Exception {
        // add country
        String countryResponse = mockMvc.perform(post(SAMPLE_PATH + "/countries").with(csrf())
                        .contentType(APPLICATION_JSON).content("{\"name\":\"Switzerland\"}").session(session))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString(StandardCharsets.UTF_8);
        log.info(countryResponse);
        SampleCountry country = objectMapper.readValue(countryResponse, SampleCountry.class);
        assertThat(country.getName(), equalTo("Switzerland"));

        String getCountryResponse = mockMvc.perform(get(SAMPLE_PATH + "/countries/" + country.getId()).session(session))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andReturn().getResponse().getContentAsString(StandardCharsets.UTF_8);
        log.info(getCountryResponse);
        country = objectMapper.readValue(getCountryResponse, SampleCountry.class);
        assertThat(country.getName(), equalTo("Switzerland"));
    }

    @Test
    void testCountries() throws Exception {
        // no county yet
        String noCountryResponse = mockMvc.perform(get(SAMPLE_PATH + "/countries").session(session))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andReturn().getResponse().getContentAsString(StandardCharsets.UTF_8);
        log.info(noCountryResponse);
        SampleCountry[] noCountry = objectMapper.readValue(noCountryResponse, SampleCountry[].class);
        assertThat(noCountry, arrayWithSize(0));

        // add country
        mockMvc.perform(post(SAMPLE_PATH + "/countries").with(csrf())
                        .contentType(APPLICATION_JSON).content("{\"name\":\"Switzerland\"}").session(session))
                .andExpect(status().isOk());

        // one country
        String oneCountryResponse = mockMvc.perform(get(SAMPLE_PATH + "/countries").session(session))
                .andExpect(status().isOk())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andReturn().getResponse().getContentAsString(StandardCharsets.UTF_8);
        log.info(oneCountryResponse);
        SampleCountry[] oneCountry = objectMapper.readValue(oneCountryResponse, SampleCountry[].class);
        assertThat(oneCountry, arrayWithSize(1));
        assertThat(oneCountry[0].getName(), equalTo("Switzerland"));

        // delete country
        String deletedCountryResponse = mockMvc.perform(delete(SAMPLE_PATH + "/countries/" + oneCountry[0].getId()).with(csrf())
                        .contentType(APPLICATION_JSON).session(session))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString(StandardCharsets.UTF_8);
        log.info(deletedCountryResponse);
    }

    @Test
    void testValidationExceptions() throws Exception {
        // add invalid country
        String invalidCountryProblem = mockMvc.perform(post(SAMPLE_PATH + "/countries").with(csrf())
                        .contentType(APPLICATION_JSON).content("{\"name\":\"Ba\"}").session(session))
                .andExpect(status().is4xxClientError())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andReturn().getResponse().getContentAsString(StandardCharsets.UTF_8);
        log.info(invalidCountryProblem);
        assertThat(invalidCountryProblem, containsString("Bad Request"));
        assertThat(invalidCountryProblem, containsString("MethodArgumentNotValidException"));
        assertThat(invalidCountryProblem, containsString("/api/sample/countries"));
        assertThat(invalidCountryProblem, containsString("validationErrors"));
        assertThat(invalidCountryProblem, containsString("sample.country.error.name.length"));

        // add country
        mockMvc.perform(post(SAMPLE_PATH + "/countries").with(csrf())
                        .contentType(APPLICATION_JSON).content("{\"name\":\"Switzerland\"}").session(session))
                .andExpect(status().isOk());
        // add same country again: SampleCountryNameAlreadyExistsException
        String countryAlreadyExistProblem = mockMvc.perform(post(SAMPLE_PATH + "/countries").with(csrf())
                        .contentType(APPLICATION_JSON).content("{\"name\":\"Switzerland\"}").session(session))
                .andExpect(status().is4xxClientError())
                .andExpect(content().contentType(APPLICATION_JSON))
                .andReturn().getResponse().getContentAsString(StandardCharsets.UTF_8);
        log.info(countryAlreadyExistProblem);
        assertThat(countryAlreadyExistProblem, containsString("Bad Request"));
        assertThat(countryAlreadyExistProblem, containsString("sample.country.error.name.exists"));
        assertThat(countryAlreadyExistProblem, containsString("/api/sample/countries"));
    }
}
