package ch.movielist.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.context.ImportTestcontainers;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@ActiveProfiles({"unittest", "app-form-security", "api-basic-security", "admin-form-security"})
@SpringBootTest
@EnableAutoConfiguration
@Transactional
@Testcontainers
@ImportTestcontainers(MovielistTestcontainers.class)
@EmbeddedKafka(topics = "sample-topic")
public @interface MovielistUnitTest {
}
