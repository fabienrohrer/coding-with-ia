package ch.movielist.config.security.authorization;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AuthorizeHttpRequestsConfigurer;
import org.springframework.stereotype.Component;

import static ch.movielist.web.core.CoreContext.*;

@Component
public class RequestMatchersConfigurer {
    public void configureAppRequestMatchers(AuthorizeHttpRequestsConfigurer<HttpSecurity>.AuthorizationManagerRequestMatcherRegistry authz) {
        authz
            // Static resources
            .requestMatchers("/",
                    "/*.*",
                    "/ui/**",
                    "/assets/**",
                    "/media/**",
                    "/scripts/**",
                    "/error",
                    "/favicon.ico").permitAll()
            // Swagger
            .requestMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll()
            // Internal REST API
            .requestMatchers(HEALTH_PATH + "**", INFO_PATH + "**", PROMETHEUS_PATH + "*").permitAll()
            .requestMatchers(INTERNAL_API_PATH + "core/translations/**").permitAll()
            .requestMatchers(INTERNAL_API_PATH + "**").hasAnyAuthority(Scope.ADMIN.getScope(), Scope.GUEST.getScope())
            .requestMatchers(AUTH_PATH + "users/current").hasAnyAuthority(Scope.ADMIN.getScope(), Scope.GUEST.getScope())
            // Deny every request which is not explicitly configured
            .anyRequest().denyAll();
    }

    public void configureApiRequestMatchers(AuthorizeHttpRequestsConfigurer<HttpSecurity>.AuthorizationManagerRequestMatcherRegistry authz) {
        authz
            .requestMatchers(EXTERNAL_API_PATH + "**").hasAuthority(Scope.API.getScope())
            .anyRequest()
            .denyAll();
    }
}
