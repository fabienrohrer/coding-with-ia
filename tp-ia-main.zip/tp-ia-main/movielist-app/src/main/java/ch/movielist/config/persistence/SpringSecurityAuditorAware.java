package ch.movielist.config.persistence;

import jakarta.annotation.Nonnull;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.security.Principal;
import java.util.Optional;

/**
 * Provides the current username.
 */
@Component
public class SpringSecurityAuditorAware implements AuditorAware<String> {

    private static final String SYSTEM_USERNAME = "SYSTEM";

    @Override
    public @Nonnull Optional<String> getCurrentAuditor() {
        return getName()
            .or(() -> Optional.of(SYSTEM_USERNAME));
    }

    private Optional<String> getName() {
        return Optional.ofNullable(SecurityContextHolder.getContext())
            .map(SecurityContext::getAuthentication)
            .map(Principal::getName);
    }
}
