package ch.movielist.config.web;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class FilterConfiguration {

    @Bean
    public FilterRegistrationBean<ClientInfoLoggingFilter> clientInfoLoggingFilterRegistration() {
        FilterRegistrationBean<ClientInfoLoggingFilter> registration = new FilterRegistrationBean<>(new ClientInfoLoggingFilter());
        registration.setUrlPatterns(List.of("/*"));
        registration.setMatchAfter(false);
        registration.setAsyncSupported(true);
        return registration;
    }
}
