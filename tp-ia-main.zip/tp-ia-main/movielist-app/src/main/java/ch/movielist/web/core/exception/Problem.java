package ch.movielist.web.core.exception;

import ch.movielist.domain.exception.ValidationError;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.io.Serializable;
import java.net.URI;
import java.util.List;

/**
 * Problem request body according to https://tools.ietf.org/html/rfc7807#section-3.1
 *
 * @see <a href="https://tools.ietf.org/html/rfc7807#section-3.1">https://tools.ietf.org/html/rfc7807#section-3.1</a>
 */
@Getter
@RequiredArgsConstructor
class Problem implements Serializable {
    private final URI type;
    private final String title;
    private final int status;
    private final String detail;
    private final URI instance;
    private final List<ValidationError> validationErrors;

    public Problem(Problem problem, List<ValidationError> validationErrors) {
        this(problem.getType(), problem.getTitle(), problem.getStatus(), problem.getDetail(), problem.getInstance(), validationErrors);
    }
}
