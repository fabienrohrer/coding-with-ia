package ch.movielist.config.web;

import org.slf4j.MDC;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;

public class ClientInfoLoggingFilter implements Filter {
    public static final String UNKNOWN = "unknown";
    public static final String ANONYMOUS = "anonymous";
    public static final String IP_ADDRESS = "clientHost";
    public static final String USERNAME = "username";

    @Override
    public void init(FilterConfig config) {
        // no initialization needed
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
        ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        try {
            String clientHost = httpRequest.getRemoteHost();
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String username = authentication == null ? ANONYMOUS : authentication.getName();
            // add the context variables
            MDC.put(IP_ADDRESS, (clientHost != null) ? clientHost : UNKNOWN);
            MDC.put(USERNAME, (username != null) ? username : ANONYMOUS);
            chain.doFilter(request, response);
        } finally {
            // no matter what happens, clean up
            // the variables associated with this Thread/Request
            MDC.remove(IP_ADDRESS);
            MDC.remove(USERNAME);
        }
    }

    @Override
    public void destroy() {
        // no initialization needed
    }
}
