package ch.movielist.web.sample.controller;

import ch.movielist.domain.model.SampleCountry;
import ch.movielist.domain.repository.SampleCountryRepository;
import ch.movielist.process.SampleCountryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static ch.movielist.web.sample.SampleContext.SAMPLE_PATH;
import static ch.movielist.web.sample.SampleContext.SAMPLE_EXTERNAL_API_PATH;

/**
 * This is a sample resource for managing countries.
 */
@RestController
@RequestMapping({SAMPLE_PATH + "/countries", SAMPLE_EXTERNAL_API_PATH + "/countries"})
@RequiredArgsConstructor
@Slf4j
public class SampleCountryController {
    private final SampleCountryRepository sampleCountryRepository;
    private final SampleCountryService sampleCountryService;

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public List<SampleCountry> getAll() {
        return sampleCountryRepository.findAllByOrderById();
    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public SampleCountry getOne(@PathVariable Long id) {
        return sampleCountryRepository.findById(id).orElseThrow();
    }

    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public SampleCountry save(@Validated @RequestBody SampleCountry country) {
        return sampleCountryService.save(country);
    }

    @PutMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public SampleCountry update(@PathVariable Long id, @Validated @RequestBody SampleCountry updatedCountry) {
        return sampleCountryService.update(id, updatedCountry);
    }

    @DeleteMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Long delete(@PathVariable Long id) {
        log.info("Deleting country with id {}", id);
        sampleCountryRepository.deleteById(id);
        return id;
    }

    @GetMapping(value = "/error", produces = MediaType.APPLICATION_JSON_VALUE)
    public String triggerError() {
        // to demonstrate an unexpected error with HttpStatus=500
        throw new IllegalStateException("Triggered an unexpected error");
    }
}
