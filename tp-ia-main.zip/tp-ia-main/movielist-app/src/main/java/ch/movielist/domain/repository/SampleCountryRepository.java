package ch.movielist.domain.repository;

import ch.movielist.domain.model.SampleCountry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SampleCountryRepository extends JpaRepository<SampleCountry, Long> {
    List<SampleCountry> findByName(String name);

    List<SampleCountry> findAllByOrderById();
}
