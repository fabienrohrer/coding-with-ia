package ch.movielist.config.security.authorization;

public enum Scope {
    ADMIN, GUEST, API, SUPPORT;

    public String getScope() {
        return "SCOPE_" + this.name();
    }
}
