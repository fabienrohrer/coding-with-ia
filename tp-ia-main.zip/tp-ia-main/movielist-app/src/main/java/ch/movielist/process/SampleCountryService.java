package ch.movielist.process;

import ch.movielist.domain.exception.ValidationException;
import ch.movielist.domain.model.SampleCountry;
import ch.movielist.domain.repository.SampleCountryRepository;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class SampleCountryService {

    private final SampleCountryRepository sampleCountryRepository;
    private final Counter saveCounter;

    public SampleCountryService(SampleCountryRepository sampleCountryRepository, MeterRegistry registry) {
        saveCounter = registry.counter("country.save.call");
        this.sampleCountryRepository = sampleCountryRepository;
    }

    public void deleteById(Long id) {
        sampleCountryRepository.deleteById(id);
    }

    public SampleCountry save(SampleCountry newCountry) {
        this.saveCounter.increment();
        ensureNameDoesNotExist(newCountry.getName());
        return sampleCountryRepository.save(newCountry);
    }

    public SampleCountry update(Long id, SampleCountry updatedCountry) {
        SampleCountry existingCountry = sampleCountryRepository.getReferenceById(id);
        ensureNameDoesNotExist(updatedCountry.getName());
        existingCountry.setName(updatedCountry.getName());
        return sampleCountryRepository.save(existingCountry);
    }

    /**
     * @param name Country name to be checked.
     */
    private void ensureNameDoesNotExist(String name) {
        if (!sampleCountryRepository.findByName(name).isEmpty()) {
            throw ValidationException.of(SampleCountry.class.getSimpleName(), "name", name, "sample.country.error.name.exists");
        }
    }
}
