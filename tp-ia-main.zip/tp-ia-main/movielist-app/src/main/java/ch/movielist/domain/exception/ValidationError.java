package ch.movielist.domain.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.io.Serializable;

@Getter
@RequiredArgsConstructor
public final class ValidationError implements Serializable {
    private final String entity;
    private final String property;
    private final transient Object invalidValue;
    private final String message;

    public ValidationError(String entity, String message) {
        this(entity, null, null, message);
    }
}
