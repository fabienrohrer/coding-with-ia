package ch.movielist.domain.model;

import lombok.*;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder(builderClassName = "Builder")
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@Entity
@Table(name = "COUNTRY")
@EntityListeners(AuditingEntityListener.class)
public class SampleCountry {

    @Id
    @SequenceGenerator(sequenceName = "COUNTRY_ID_SEQ", name = "COUNTRY_ID_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "COUNTRY_ID_SEQ")
    @Column(name = "ID")
    private Long id;

    @NotBlank(message = "sample.country.error.description.blank")
    @Length(min = 3, max = 140, message = "sample.country.error.name.length")
    @Column(name = "NAME")
    private String name;

    @Column(name = "CREATION_USER", nullable = false)
    @CreatedBy
    private String creationUser;

    @Column(name = "CREATION_DATE", nullable = false)
    @CreatedDate
    private LocalDateTime creationDate;

    @Column(name = "MUTATION_USER", nullable = false)
    @LastModifiedBy
    private String mutationUser;

    @Column(name = "MUTATION_DATE", nullable = false)
    @LastModifiedDate
    private LocalDateTime mutationDate;
}
