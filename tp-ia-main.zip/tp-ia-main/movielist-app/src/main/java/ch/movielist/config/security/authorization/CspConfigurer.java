package ch.movielist.config.security.authorization;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.stereotype.Component;

@Component
public class CspConfigurer {

    @Value("${movielist.csp.default-src}")
    private String defaultSrc;

    @Value("${movielist.csp.script-src}")
    private String scriptSrc;

    @Value("${movielist.csp.style-src}")
    private String styleSrc;

    @Value("${movielist.csp.img-src}")
    private String imgSrc;

    @Value("${movielist.csp.connect-src}")
    private String connectSrc;

    @Value("${movielist.csp.form-action}")
    private String formAction;

    @Value("${movielist.csp.base-uri}")
    private String baseUri;

    @Value("${movielist.csp.font-src}")
    private String fontSrc;

    @Value("${movielist.csp.frame-src}")
    private String frameSrc;

    public void configure(HttpSecurity http) throws Exception {
        http.headers(httpSecurityHeadersConfigurer -> httpSecurityHeadersConfigurer
            .contentSecurityPolicy(contentSecurityPolicyConfig -> contentSecurityPolicyConfig
                .policyDirectives(
                    "default-src " + defaultSrc +
                    "script-src " + scriptSrc +
                    "style-src " + styleSrc +
                    "img-src " + imgSrc +
                    "connect-src " + connectSrc +
                    "form-action " + formAction +
                    "base-uri " + baseUri +
                    "font-src " + fontSrc +
                    "frame-src " + frameSrc)));
    }
}
