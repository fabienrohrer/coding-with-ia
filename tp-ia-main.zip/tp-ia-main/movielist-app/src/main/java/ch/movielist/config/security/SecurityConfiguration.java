package ch.movielist.config.security;

import ch.movielist.config.security.authorization.CspConfigurer;
import ch.movielist.config.security.authorization.RequestMatchersConfigurer;
import ch.movielist.config.security.authorization.Scope;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.CsrfConfigurer;
import org.springframework.security.oauth2.server.resource.authentication.JwtIssuerAuthenticationManagerResolver;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.logout.HttpStatusReturningLogoutSuccessHandler;
import org.springframework.security.web.authentication.logout.LogoutFilter;
import org.springframework.security.web.authentication.switchuser.SwitchUserFilter;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfTokenRequestAttributeHandler;

import java.util.List;

import static ch.movielist.web.core.CoreContext.AUTH_PATH;
import static ch.movielist.web.core.CoreContext.EXTERNAL_API_PATH;
import static org.springframework.security.config.Customizer.withDefaults;


@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@Slf4j
@RequiredArgsConstructor
public class SecurityConfiguration {

    private static final String ALL_PATHS = "/**";

    private final CspConfigurer cspConfigurer;
    private final RequestMatchersConfigurer requestMatchersConfigurer;
    private final CsrfTokenRequestAttributeHandler csrfTokenRequestAttributeHandler;


    /**
     * Application slice: Api
     * Authentication strategy: Basic auth login (development authentication only, not intended to be used in production)
     */
    @Bean
    @Order(1)
    @Profile("api-basic-security")
    public SecurityFilterChain apiBasicSecurityFilterChain(HttpSecurity http) throws Exception {
        notForUseInProductionWarning();
        http.securityMatcher(EXTERNAL_API_PATH + "**")
            .authorizeHttpRequests(requestMatchersConfigurer::configureApiRequestMatchers)
            .httpBasic(withDefaults())
            .csrf(this::configureCsrf);
        return http.build();
    }


    /**
     * Application slice: Admin
     * Authentication strategy: Form login (development authentication only, not intended to be used in production)
     */
    @Bean
    @Order(2)
    @Profile("admin-form-security")
    public SecurityFilterChain adminFormSecurityFilterChain(HttpSecurity http) throws Exception {
        notForUseInProductionWarning();
        final var LOGIN_PROCESSING_URL = "/admin/login";
        final var LOGIN_PAGE = "/admin/login.html";
        http.securityMatcher("/admin/**")
            .authorizeHttpRequests(authz -> authz
                .requestMatchers("/admin", LOGIN_PAGE, LOGIN_PROCESSING_URL).permitAll()
                .requestMatchers("/admin/**").hasAuthority(Scope.SUPPORT.getScope())
                // Deny every request which is not explicitly configured
                .anyRequest().denyAll())
            .formLogin((formLoginConfigurer -> formLoginConfigurer
                .loginPage(LOGIN_PAGE).permitAll()
                .loginProcessingUrl(LOGIN_PROCESSING_URL)
                .defaultSuccessUrl("/admin", true)))
            .exceptionHandling(httpSecurityExceptionHandlingConfigurer -> httpSecurityExceptionHandlingConfigurer
                .accessDeniedPage(LOGIN_PAGE))
            .csrf(crsf -> configureCsrf(crsf).ignoringRequestMatchers(LOGIN_PROCESSING_URL));
        cspConfigurer.configure(http);
        return http.build();
    }

    /**
     * Application slice: App
     * Authentication strategy: Form login (development authentication only, not intended to be used in production)
     */
    @Bean
    @Order(3)
    @Profile("app-form-security")
    public SecurityFilterChain appFormSecurityFilterChain(HttpSecurity http) throws Exception {
        notForUseInProductionWarning();
        final var LOGIN_PROCESSING_URL = "/auth/*";
        http
            .securityMatcher(ALL_PATHS)
            .authorizeHttpRequests(requestMatchersConfigurer::configureAppRequestMatchers)
            .formLogin(formLoginConfigurer -> formLoginConfigurer.loginPage(AUTH_PATH + "login").permitAll())
            .exceptionHandling(httpSecurityExceptionHandlingConfigurer -> httpSecurityExceptionHandlingConfigurer
                    .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED)))
            .logout(httpSecurityLogoutConfigurer -> httpSecurityLogoutConfigurer
                    .logoutUrl(AUTH_PATH + "logout").permitAll()
                    .logoutSuccessHandler(new HttpStatusReturningLogoutSuccessHandler(HttpStatus.OK)))
            .csrf(crsf -> configureCsrf(crsf).ignoringRequestMatchers(LOGIN_PROCESSING_URL));
        cspConfigurer.configure(http);
        return http.build();
    }

    private CsrfConfigurer<HttpSecurity> configureCsrf(CsrfConfigurer<HttpSecurity> httpSecurityCsrfConfigurer) {
        return httpSecurityCsrfConfigurer
            .csrfTokenRequestHandler(csrfTokenRequestAttributeHandler)
            .csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse());
    }

    public static void notForUseInProductionWarning() {
        log.warn("This configuration is not intended to be used in production!");
    }
}
