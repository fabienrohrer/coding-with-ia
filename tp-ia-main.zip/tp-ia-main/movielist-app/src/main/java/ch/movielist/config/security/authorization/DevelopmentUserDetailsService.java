package ch.movielist.config.security.authorization;

import ch.movielist.config.security.SecurityConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

/**
 * UserDetailsService with default users for development only.
 */
@Configuration
@Slf4j
public class DevelopmentUserDetailsService {
    @Profile("dev-authentication")
    @Bean
    public UserDetailsService userDetailsService() {
        SecurityConfiguration.notForUseInProductionWarning();
        final var manager = new InMemoryUserDetailsManager();
        addUser(manager, Scope.ADMIN);
        addUser(manager, Scope.GUEST);
        addUser(manager, Scope.API);
        addUser(manager, Scope.SUPPORT);
        return manager;
    }

    private void addUser(InMemoryUserDetailsManager manager, Scope scope) {
        manager.createUser(User.withUsername(scope.name().toLowerCase())
                .password("{noop}" + scope.name().toLowerCase())
                .authorities(scope.getScope())
                .build());
    }
}
