package ch.movielist.domain.exception;

import java.util.List;

/**
* Domain-level validation exception for business rule violations.
* Thrown by the process/service layer when business validation fails.
*/
public class ValidationException extends RuntimeException {
    private final List<ValidationError> validationErrors;

    public static ValidationException of(String entity, String message) {
        return new ValidationException(List.of(new ValidationError(entity, message)));
    }

    public static ValidationException of(String entity, String property, Object invalidValue, String message) {
        return new ValidationException(List.of(new ValidationError(entity, property, invalidValue, message)));
    }

    public ValidationException(ValidationError validationError) {
        this.validationErrors = List.of(validationError);
    }

    public ValidationException(List<ValidationError> validationErrors) {
        this.validationErrors = validationErrors;
    }

    public List<ValidationError> getValidationErrors() {
        return validationErrors;
    }
}
