package ch.movielist.web.core.exception;

import ch.movielist.domain.exception.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.util.WebUtils;

/**
 * Handles exception according to RFC-7807
 *
 * @see <a href="https://tools.ietf.org/html/rfc7807">RFC-7807</a>
 */
@RestControllerAdvice
@Slf4j
public class ProblemExceptionHandler extends ResponseEntityExceptionHandler {

    /**
     * This makes {@link ResponseEntityExceptionHandler} return a Problem body.
     */
    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers, HttpStatusCode statusCode, WebRequest request) {
        return handleExceptionAsProblem(ex, headers, statusCode, request);
    }

    /*
     * Different types of exceptions can be added here. They will be returned as problems.
     */
    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<Object> handleValidationExceptions(Exception ex, WebRequest webRequest) {
        return handleExceptionAsProblem(ex, new HttpHeaders(), HttpStatus.BAD_REQUEST, webRequest);
    }

    private ResponseEntity<Object> handleExceptionAsProblem(Exception ex, HttpHeaders headers, HttpStatusCode status, WebRequest webRequest) {
        if (status.is4xxClientError()) {
            return new ResponseEntity<>(ProblemFactory.badRequest(ex, webRequest), headers, status);
        }
        if (HttpStatus.INTERNAL_SERVER_ERROR.equals(status)) {
            log.warn("Internal Server Error", ex);
            webRequest.setAttribute(WebUtils.ERROR_EXCEPTION_ATTRIBUTE, ex, RequestAttributes.SCOPE_REQUEST);
        }
        return new ResponseEntity<>(ProblemFactory.unexpected(ex, webRequest), headers, status);
    }
}
