package ch.movielist.web.core;

/**
 * This holds the context paths for the core functions.
 * squid:S1075: Here it makes sense to harcode URLs.
 * squid:S1118: To remove Sonar requirement for private constructor.
 */
@SuppressWarnings({"squid:S1075", "squid:S1118"})
public final class CoreContext {
    public static final String INTERNAL_API_PATH = "/api/";
    public static final String EXTERNAL_API_PATH = "/external/api/v1/";
    public static final String HEALTH_PATH = "/health/";
    public static final String PROMETHEUS_PATH = "/prometheus";
    public static final String INFO_PATH = "/info/";
    public static final String AUTH_PATH = "/auth/";

}
