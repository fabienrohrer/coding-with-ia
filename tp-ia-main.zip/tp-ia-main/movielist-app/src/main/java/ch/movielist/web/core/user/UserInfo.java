package ch.movielist.web.core.user;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * This class holds the logged user info of the application.
 */
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class UserInfo {
    private String username;
    private List<String> roles;
}
