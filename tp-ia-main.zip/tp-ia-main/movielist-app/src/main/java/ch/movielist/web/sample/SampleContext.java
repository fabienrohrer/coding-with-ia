package ch.movielist.web.sample;

import static ch.movielist.web.core.CoreContext.INTERNAL_API_PATH;
import static ch.movielist.web.core.CoreContext.EXTERNAL_API_PATH;

/**
 * This class collects the paths for the sample application.
 * squid:S1118: To remove Sonar requirement for private constructor.
 */
@SuppressWarnings("squid:S1118")
public final class SampleContext {
    public static final String SAMPLE_PATH = INTERNAL_API_PATH + "sample";
    public static final String SAMPLE_EXTERNAL_API_PATH = EXTERNAL_API_PATH + "sample";
}
