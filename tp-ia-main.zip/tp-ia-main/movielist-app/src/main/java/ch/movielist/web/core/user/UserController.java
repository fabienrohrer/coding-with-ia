package  ch.movielist.web.core.user;

import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static ch.movielist.web.core.CoreContext.AUTH_PATH;

/**
 * This class gets the logged user info of the application.
 */
@RestController
public class UserController {

    @GetMapping(value = {AUTH_PATH + "users/current"}, produces = MediaType.APPLICATION_JSON_VALUE)
    public UserInfo userInfo() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String name = auth.getName(); //get logged in username
        List<String> roles = auth.getAuthorities().stream().map(GrantedAuthority::getAuthority).toList();
        return new UserInfo(name, roles);
    }
}
