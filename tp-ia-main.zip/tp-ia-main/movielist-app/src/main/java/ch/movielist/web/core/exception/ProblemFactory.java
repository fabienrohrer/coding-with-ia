package ch.movielist.web.core.exception;

import ch.movielist.domain.exception.ValidationError;
import ch.movielist.domain.exception.ValidationException;
import org.springframework.http.HttpStatus;
import org.springframework.validation.Errors;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;

import java.net.URI;
import java.util.stream.Stream;

/**
 * Creates {@link Problem} payload that conforms to RFC-7807 from Exception and {@link WebRequest}.
 * <p>
 * When {@link MethodArgumentNotValidException} or {@link ValidationException} a ValidationProblem payload is created.
 *
 * @see <a href="https://tools.ietf.org/html/rfc7807">RFC-7807</a>
 */
final class ProblemFactory {

    static Problem unexpected(Exception ex, WebRequest webRequest) {
        String requestURI = webRequest.getContextPath();
        if (webRequest instanceof ServletWebRequest servletWebRequest) {
            requestURI = servletWebRequest.getRequest().getRequestURI();
        }
        return new Problem(URI.create("about:blank"), ex.getClass().getSimpleName(), HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(), URI.create(requestURI), null);
    }

    static Problem badRequest(Exception ex, WebRequest webRequest) {
        String requestURI = webRequest.getContextPath();
        if (webRequest instanceof ServletWebRequest servletWebRequest) {
            requestURI = servletWebRequest.getRequest().getRequestURI();
        }
        Problem problem = new Problem(URI.create(webRequest.getContextPath() + "/" + ex.getClass().getSimpleName()), ex.getClass().getSimpleName(), HttpStatus.BAD_REQUEST.value(), HttpStatus.BAD_REQUEST.getReasonPhrase(), URI.create(requestURI), null);
        if (ex instanceof ValidationException validationException) {
            return new Problem(problem, validationException.getValidationErrors());
        }
        if (ex instanceof MethodArgumentNotValidException methodArgumentNotValidException) {
            return problemFromErrors(problem, methodArgumentNotValidException.getBindingResult());
        }
        return problem;
    }

    private static Problem problemFromErrors(Problem problem, Errors errors) {
        return new Problem(problem,
            Stream.concat(errors.getFieldErrors().stream()
                    .map(error -> new ValidationError(error.getObjectName(), error.getField(), error.getRejectedValue(), error.getDefaultMessage())),
                errors.getGlobalErrors().stream()
                    .map(error -> new ValidationError(error.getObjectName(), error.getDefaultMessage()))
            ).toList());
    }

    private ProblemFactory() {
    }
}
