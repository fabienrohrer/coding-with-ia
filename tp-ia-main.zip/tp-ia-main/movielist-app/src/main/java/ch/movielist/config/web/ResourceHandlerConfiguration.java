package ch.movielist.config.web;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.CacheControl;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.resource.EncodedResourceResolver;

import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

@Configuration
public class ResourceHandlerConfiguration {
    private static final int CACHE_MAX_DAYS = 365;

    @Bean
    public EncodedResourceResolver encodedResourceResolver() {
        return new EncodedResourceResolver();
    }

    /**
     * Caching period is set to maximum, because:
     * - angular-cli serves the static files and manages caching as expected
     * - not angular-cli: at build time each filename receives a suffix based on its hash, so we can cache it forever
     * Important: the filter does not match "/" because the index.html must never be cached to not break the mechanism
     * described above.
     */
    @Bean("resourceHandlerConfigurer")
    public Consumer<ResourceHandlerRegistry> resourceHandlerConfigurer() {
        return (registry -> {
            registry.addResourceHandler("/admin/**")
                .addResourceLocations("classpath:static/admin/");
            registry.addResourceHandler("/**")
                            .addResourceLocations("classpath:/META-INF/resources/webjars/movielist-web-client/")
                            .setCacheControl(CacheControl.maxAge(CACHE_MAX_DAYS, TimeUnit.DAYS))
                            .resourceChain(true)
                            .addResolver(encodedResourceResolver());
            registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
        });
    }
}
