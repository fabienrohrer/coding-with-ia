# GETTING STARTED GUIDE (WINDOWS)

Once installation is complete, follow these steps to launch the movielist project on Windows.

## 0. Windows Setup (quick checklist)

These are the known working prerequisites from a colleague's setup. Adjust paths if needed.

- JetBrains Toolbox: https://www.jetbrains.com/toolbox-app/
- IntelliJ IDEA (Java)
- JDK 25 (Temurin): https://adoptium.net/fr/download?link=https%3A%2F%2Fgithub.com%2Fadoptium%2Ftemurin25-binaries%2Freleases%2Fdownload%2Fjdk-25.0.1%252B8%2FOpenJDK25U-jdk_x64_windows_hotspot_25.0.1_8.msi&vendor=Adoptium
- Maven 3.8.5
- Node.js 22.22.0
- Docker Desktop 4.56.0

Suggested install paths (from the tested setup):

- `D:\work\jrepo-local\tools\java\jdk-25.0.1+8`
- `D:\work\jrepo-local\tools\maven\apache-maven-3.8.5`
- `D:\work\jrepo-local\tools\node\node-v22.22.0-win-x64`

### IntelliJ configuration

- Set the project SDK to Java 25 (Project Structure / F4).
- In Settings > Maven, set the Maven home path to 3.8.5.
- Unzip the project to `D:\work\projects\movielist` (or any local folder).
- Import the project as a Maven project.

## 1. Launch PostgreSQL with Docker Compose

From the project root, start the PostgreSQL database:

```powershell
# Start the services (PostgreSQL + Adminer)
docker compose up -d

# Verify that containers are running
docker ps
```

You should see two active containers: `tp-ia-postgres-1` and `tp-ia-adminer-1`.

### PostgreSQL Connection Details

The PostgreSQL password is **hardcoded** in the following locations:

1. **Docker Compose configuration** (`compose.yaml`):
   ```yaml
   environment:
       POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
   ```
   The password defaults to: `myPassword` (see `movielist-app/src/main/resources/config/application-default.yaml`)

2. **Spring Boot configuration** (`movielist-app/src/main/resources/config/application-default.yaml`):
   ```yaml
   spring:
     datasource:
       password: ${POSTGRES_PASSWORD:myPassword}
   ```
   The default value is `myPassword`. This can be overridden by setting the `POSTGRES_PASSWORD` environment variable.

### Verify PostgreSQL with Adminer

- Open your browser and go to: **http://localhost:8082**
- You should see the adminer login page.
- Server: `postgres`
- User: `postgres`
- Password: `myPassword`
- Database: (leave empty)

## 2. Build and Launch the Spring Boot Backend

### Build the Maven Project

From the project root:

```powershell
# Clean and compile
mvn clean install

# Or if you just want to compile (skip tests)
mvn clean install -DskipTests
```

### Launch the Spring Boot Application

From IntelliJ, run `MovielistApplication`.

Or from the terminal:

```powershell
cd movielist-app
mvn spring-boot:run
```

### Verify the Backend is Running

Once started, the application should be accessible at:

```
http://localhost:8080
```

## 3. Launch the Angular Frontend

### Install npm Dependencies (first time only)

```powershell
cd movielist-web-client
npm install
```

### Start the Angular Development Server

```powershell
npm run start
```

The frontend should open at:

```
http://localhost:4200
```

If you edit any Angular file, the dev server should reload the page automatically.

## 4. Install GitHub Copilot

- Install the GitHub Copilot plugin from IntelliJ Marketplace.
- Log in with your GitHub account.


