# One feature per feature-file
# The different scenarios demonstrate the different aspects of the feature
Feature: Manage countries

    @country
    Scenario: Create a country
        Given The user loads the application on ui/countries and logs in as admin / admin
        And The user navigates to ui/countries
        And Deletes all countries
        # Create one
        When Clicks the element with id country_new
        When Fills the input with id name with text France
        And Clicks the element with id save
        Then The element with id country_name_0 has text France

        # Cleanup
        And Clicks the element with id country_delete_0

    @country
    Scenario: Update a country
        Given The user loads the application on ui/countries and logs in as admin / admin
        And The user navigates to ui/countries
        And Deletes all countries
        # Create one
        When Clicks the element with id country_new
        When Fills the input with id name with text France
        And Clicks the element with id save
        Then The element with id country_name_0 has text France
        # Update it
        When Clicks the element with id country_edit_0
        And Fills the input with id name with text Belgium
        And Clicks the element with id save
        Then The element with id country_name_0 has text Belgium

        # Cleanup
        And Clicks the element with id country_delete_0
