package ch.movielist.web.test.cucumber;

import ch.movielist.config.TestWebTestConfiguration;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;

@RunWith(Cucumber.class)
@CucumberOptions(
    plugin = {"pretty", "html:target/cucumber/index.html", "json:target/cucumber-json-report.json"},
    features = {"classpath:/movielist/features/"},
    glue = "ch.movielist.web.test.steps",
    monochrome = true
)
@ContextConfiguration(classes = TestWebTestConfiguration.class)
public class RunCucumber {}
