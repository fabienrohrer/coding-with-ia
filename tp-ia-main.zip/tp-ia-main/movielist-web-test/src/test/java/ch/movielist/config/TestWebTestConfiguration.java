package ch.movielist.config;

import ch.movielist.web.test.cucumber.SeleniumManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TestWebTestConfiguration {

    @Bean
    public SeleniumManager seleniumManager() {
        return new SeleniumManager();
    }

}
