package ch.movielist.web.test.steps;

import ch.movielist.config.TestWebTestConfiguration;
import ch.movielist.web.test.cucumber.SeleniumManager;
import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.*;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Steps are the reusable blocks of the Cucumber tests.
 * <ul>
 *     <li>Try to define one block per user action (click on something, etc.) or assertion</li>
 *     <li>You can organize them in different classes (like login and initialization steps, form steps, use case specific special steps, etc.)</li>
 *     <li>Try to always be pessimistic in your steps, using explicit waits:
 *          <ul>
 *              <li>Example: when you use an element, wait on it to appear (don't expect it to already be available)</li>
 *              <li>Try to wait on things to happen (with WebDriverWait) instead of just asserting (and expecting it has happened before!)</li>
 *           </ul>
 *     </li>
 * </ul>
 */
@CucumberContextConfiguration
@ContextConfiguration(classes = TestWebTestConfiguration.class)
public class SampleStep {
    private static final Logger LOGGER = LoggerFactory.getLogger(SampleStep.class);

    @Autowired
    private SeleniumManager seleniumManager;

    @Value("${selenium.screenshotsPath:target}")
    private String screenshotsPath;

    private WebDriver d;

    @After("@country")
    public void afterCountryScenario(final Scenario scenario) {
        if (scenario.isFailed()) {
            takeScreenshot(scenario.getId().replaceAll(":", "__") + "__failed");
            createLogDumpFiles(scenario.getId().replaceAll(":", "__") + "__failed");
        }
    }

    public void createLogDumpFiles(final String screenshotId) {
        var url = seleniumManager.getDriver().getCurrentUrl().replaceAll("[^a-zA-Z0-9-_.]", "_");
        try {
            for (String logType : seleniumManager.getDriver().manage().logs().getAvailableLogTypes()) {
                String fileName = String.format("logs_%s_%s_%s.txt", logType, screenshotId, url);
                Path filePath = Path.of("target", fileName);
                try (PrintWriter w = new PrintWriter(Files.newBufferedWriter(filePath, StandardCharsets.UTF_8))) {
                    LogEntries logEntries = seleniumManager.getDriver().manage().logs().get(logType);
                    for (LogEntry entry : logEntries.getAll()) {
                        w.println(entry);
                    }
                    w.println();
                }
                LOGGER.debug("Log Type {} saved to {}", logType, filePath);
            }
        } catch (final IOException e) {
            LOGGER.error("No Console dump saved", e);
        } catch (final Exception e) {
            LOGGER.error("unable to create Console dump", e);
        }
    }

    @Then("^take screenshot (.*)$")
    public void takeScreenshot(final String screenshotId) {
        try {
            d = seleniumManager.getDriver();
            Thread.sleep(100);
            final File scrFile = ((TakesScreenshot) d).getScreenshotAs(OutputType.FILE);
            final String fileName = String.format("screenshot_%s.png", screenshotId);
            final String filePath = FilenameUtils.concat(screenshotsPath, fileName);

            final File file = new File(filePath);
            FileUtils.copyFile(scrFile, file);
            LOGGER.info("Screenshot saved to {}", file.getAbsolutePath());
        } catch (final Exception e) {
            LOGGER.warn("unable to create screenshot", e);
        }
    }

    @Given("^The user loads the application on (.*) and logs in as (.*) / (.*)$")
    public void login(String path, String username, String password) {
        d = seleniumManager.getDriver();

        // Delete cookies
        d.manage().deleteAllCookies();
        d.get(seleniumManager.getUrl());

        // Clear LocalStorage
        JavascriptExecutor js = (JavascriptExecutor) d;
        js.executeScript("window.localStorage.clear();");

        // Login
        LOGGER.info("url={}{}", seleniumManager.getUrl(), path);
        LOGGER.info("User logs in as {}", username);
        d.get(seleniumManager.getUrl() + path);
        Assertions.assertFalse(d.findElements(By.id("username")).isEmpty(), "Login screen should be visible");
        d.findElement(By.id("username")).sendKeys(username);
        d.findElement(By.id("password")).sendKeys(password);
        d.findElement(By.id("login_form_button")).submit();

        // We wait until the login is done (page does not contain login_form anymore)
        (new WebDriverWait(d, SeleniumManager.EXPLICIT_WAIT_TIMEOUT)).until(
            (ExpectedCondition<Boolean>) webDriver
                -> !d.findElement(By.tagName("body")).getAttribute("innerHTML").contains("login_form"));
    }

    @When("^The user navigates to (.*)$")
    public void userNavigatesTo(String url) {
        d = seleniumManager.getDriver();

        // Go to the given URL
        d.get(seleniumManager.getUrl() + url);
    }

    @And("^Selects the option (.*) in the select with id (.*)")
    public void selectOption(Integer index, String id) {
        d = seleniumManager.getDriver();

        // Wait on select to have options
        (new WebDriverWait(d, SeleniumManager.EXPLICIT_WAIT_TIMEOUT)).until(
            (ExpectedCondition<Boolean>) webDriver -> new Select(d.findElement(By.id(id))).getOptions().size() > 1);

        // Select a specific option in the drop down
        new Select(d.findElement(By.id(id))).selectByIndex(index);
    }

    @And("^Clicks the element with id (.*)$")
    public void clickElement(String id) {
        d = seleniumManager.getDriver();

        (new WebDriverWait(d, SeleniumManager.EXPLICIT_WAIT_TIMEOUT))
            .until((ExpectedCondition<Boolean>) webDriver -> {
                    try {
                        // wait on element to be visible
                        (new WebDriverWait(d, SeleniumManager.EXPLICIT_WAIT_TIMEOUT))
                            .until(ExpectedConditions.elementToBeClickable(By.id(id)));

                        // Click it
                        d.findElement(By.id(id)).click();
                        return true;
                    } catch (Exception e) {
                        LOGGER.debug("Not ready yet", e);
                        return false;
                    }
                }
            );
    }

    @And("^Clicks the checkbox with id (.*)$")
    public void clickCheckbox(String id) {
        d = seleniumManager.getDriver();

        // Wait on element to be visible
        (new WebDriverWait(d, SeleniumManager.EXPLICIT_WAIT_TIMEOUT))
            .until(ExpectedConditions.elementToBeClickable(By.id(id)));

        // Click it
        d.findElement(By.id(id)).click();
    }

    @And("^Clicks the #(\\d+) element with id (.*)$")
    public void clickAtIndex(Integer index, String id) {
        d = seleniumManager.getDriver();

        // Wait on the element to appear
        (new WebDriverWait(d, SeleniumManager.EXPLICIT_WAIT_TIMEOUT))
            .until((ExpectedCondition<Boolean>) webDriver -> {
                    try {
                        // Click it
                        d.findElements(By.id(id)).get(index).click();
                        return true;
                    } catch (Exception e) {
                        LOGGER.debug("Not true yet", e);
                        return false;
                    }
                }
            );
    }

    @Then("^The shipping appears in the results table$")
    public void shippingAppearsInTable() {
        d = seleniumManager.getDriver();

        // Wait on table to be not empty
        (new WebDriverWait(d, SeleniumManager.EXPLICIT_WAIT_TIMEOUT))
            .until((ExpectedCondition<Boolean>) webDriver -> {

                    // Just after the shipping is created, search returns nothing (timing issue).
                    // To get a stable test, we click on "search" until the result appears in the table.
                    d.findElement(By.id("search")).click();

                    // Get tr elements which are in a tbody element in a table element
                    List<WebElement> tableRows = d.findElement(By.id("searchResultsTable")).findElement(By.tagName("tbody")).findElements(By.tagName("tr"));

                    // We expect more than 1 row because we ignore the header
                    return tableRows.size() > 1;
                }
            );
    }

    @And("^Fills the input with id (.*) with text (.*)$")
    public void fillInputWithText(String id, String text) {
        d = seleniumManager.getDriver();

        // Wait on element to be visible
        (new WebDriverWait(d, SeleniumManager.EXPLICIT_WAIT_TIMEOUT))
            .until(ExpectedConditions.visibilityOfElementLocated(By.id(id)));

        WebElement el = d.findElement(By.id(id));
        el.clear();
        el.sendKeys(text);
    }

    @Then("^The (.*) #(\\d+) has text (.*)")
    public void hasText(String id, Integer index, String value) {
        d = seleniumManager.getDriver();

        // Wait on the element to appear
        (new WebDriverWait(d, SeleniumManager.EXPLICIT_WAIT_TIMEOUT))
            .until((ExpectedCondition<Boolean>) webDriver -> {
                    try {
                        // Compare its text
                        return d.findElements(By.id(id)).get(index).getText().equals(value);
                    } catch (Exception e) {
                        LOGGER.debug("Not true yet", e);
                        return false;
                    }
                }
            );
    }

    @Then("^The element with id (.*) has text (.*)$")
    public void elementHasText(String id, String value) {
        d = seleniumManager.getDriver();

        (new WebDriverWait(d, SeleniumManager.EXPLICIT_WAIT_TIMEOUT))
            .until((ExpectedCondition<Boolean>) webDriver -> {
                    try {
                        return d.findElement(By.id(id)).getText().equals(value);
                    } catch (Exception e) {
                        LOGGER.debug("Not true yet", e);
                        return false;
                    }
                }
            );
    }

    @Then("^The element #(\\d+) with id (.*) has value (.*) for attribute (.*)$")
    public void elementHasValueForAttribute(Integer index, String id, String value, String attribute) {
        d = seleniumManager.getDriver();

        (new WebDriverWait(d, SeleniumManager.EXPLICIT_WAIT_TIMEOUT))
            .until((ExpectedCondition<Boolean>) webDriver -> {
                    try {
                        return d.findElements(By.id(id)).get(index).getAttribute(attribute).equals(value);
                    } catch (Exception e) {
                        LOGGER.debug("Not true yet", e);
                        return false;
                    }
                }
            );
    }

    @Then("^The element with id (.*) has value (.*) for attribute (.*)$")
    public void elementHasValueForAttribute(String id, String value, String attribute) {
        d = seleniumManager.getDriver();

        (new WebDriverWait(d, SeleniumManager.EXPLICIT_WAIT_TIMEOUT))
            .until((ExpectedCondition<Boolean>) webDriver -> {
                    try {
                        return d.findElement(By.id(id)).getAttribute(attribute).equals(value);
                    } catch (Exception e) {
                        LOGGER.debug("Not true yet", e);
                        return false;
                    }
                }
            );
    }

    @And("^Deletes all countries$")
    public void deleteAllCountries() {
        d = seleniumManager.getDriver();
        d.findElements(By.cssSelector("[id^=country_delete_]")).forEach(countryDeleteButton -> clickElement("country_delete_0"));
    }
}
