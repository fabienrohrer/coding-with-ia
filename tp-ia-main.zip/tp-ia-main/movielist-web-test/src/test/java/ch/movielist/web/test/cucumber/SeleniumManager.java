package ch.movielist.web.test.cucumber;

import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import java.io.IOException;
import java.net.URL;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

/**
 * Initialize and configure selenium
 */
public class SeleniumManager {

    public static final int DEFAULT_TIMEOUT = 5;
    public static final Duration EXPLICIT_WAIT_TIMEOUT = Duration.ofSeconds(5);
    private static final Logger LOGGER = LoggerFactory.getLogger(SeleniumManager.class);
    private String url = "https://demoapp-internet.eks.aws.pnetcloud.ch/";

    private ChromeDriverService service;
    private WebDriver driver;

    @PostConstruct
    public void init() throws IOException {
        if (System.getProperty("ui.test.url") != null) {
            url = System.getProperty("ui.test.url");
        }

        System.setProperty("webdriver.chrome.logfile", "target/chromedriver.log");
        service = new ChromeDriverService.Builder()
            .usingAnyFreePort()
            .build();
        service.start();

        LOGGER.info("ChromeDriverService started");
    }

    @PreDestroy
    public void destroy() {
        service.stop();

        LOGGER.info("ChromeDriverService stopped");
    }

    public WebDriver getDriver() {
        if (driver == null) {
            createWebDriver(service.getUrl());
            LOGGER.info("Driver created");
        }
        return driver;
    }

    private void createWebDriver(URL remoteWebDriverUrl) {
        DesiredCapabilities caps = new DesiredCapabilities();

        LoggingPreferences logPrefs = new LoggingPreferences();
        logPrefs.enable(LogType.BROWSER, Level.ALL);
        logPrefs.enable(LogType.PERFORMANCE, Level.ALL);
        caps.setCapability("goog:loggingPrefs", logPrefs);

        List<String> arguments = new ArrayList<>();
        arguments.add("--disable-web-security");
        arguments.add("--incognito");
        arguments.add("--disable-gpu");
        arguments.add("--start-maximized");
        arguments.add("--no-sandbox");
        arguments.add("--proxy-server=outappl.pnet.ch:3128");
        arguments.add("--proxy-bypass-list=*.pnet.ch,*.pnetcloud.ch");

        // make sure that the window has portrait orientation
        arguments.add("--app-shell-host-window-size=1400x1000");
        arguments.add("--content-shell-host-window-size=1400x1000");
        arguments.add("--window-size=1400,1000");

        String chromeUserDataDir = System.getProperty("SelChromeUserDataDir");
        if (chromeUserDataDir != null) {
            arguments.add("--user-data-dir=" + chromeUserDataDir);
        }

        ChromeOptions options = new ChromeOptions();
        options.addArguments(arguments);
        options.setPageLoadStrategy(PageLoadStrategy.EAGER);

        // For use with RemoteWebDriver:
        caps.setCapability(ChromeOptions.CAPABILITY, options);

        driver = new RemoteWebDriver(remoteWebDriverUrl, caps);

        driver.manage().timeouts()
            .implicitlyWait(Duration.ofSeconds(DEFAULT_TIMEOUT));
    }

    public String getUrl() {
        return url;
    }
}
