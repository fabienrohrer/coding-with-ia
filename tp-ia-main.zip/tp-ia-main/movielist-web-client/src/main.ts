/// <reference types="@angular/localize" />

import { enableProdMode, LOCALE_ID, ErrorHandler, importProvidersFrom } from '@angular/core';
import { environment } from './environments/environment';
import { setActiveLang } from './app/common/language-configuration';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi, HttpClient } from '@angular/common/http';
import { HttpErrorInterceptor } from './app/security/http-error-interceptor';
import { AcceptLanguageInterceptor } from './app/common/accept-language-interceptor';
import { GlobalErrorHandler } from './app/error/services/global-error-handler.service';
import { bootstrapApplication } from '@angular/platform-browser';
import { provideToastr } from 'ngx-toastr';
import { provideAnimations } from '@angular/platform-browser/animations';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { SampleCountryModule } from './app/sample-country/sample-country.module';
import { SampleAuthorizationModule } from './app/sample-authorization/sample-authorization.module';
import { SecurityModule } from './app/security/security.module';
import { AppRoutingModule } from './app/app.routing.module';
import { AppComponent } from './app/app.component';

if (environment.production) {
    enableProdMode();
}



const httpLoaderFactory: (http: HttpClient) => TranslateHttpLoader = (http: HttpClient) =>
  new TranslateHttpLoader(http, '../../assets/i18n/', '.json');

bootstrapApplication(AppComponent, {
  providers: [
    importProvidersFrom(
      TranslateModule.forRoot({
        loader: {
          provide: TranslateLoader,
          useFactory: httpLoaderFactory,
          deps: [HttpClient],
        },
      }),
      SampleCountryModule,
      SampleAuthorizationModule,
      SecurityModule,
      AppRoutingModule,
    ),
    Location,
    { provide: LocationStrategy, useClass: PathLocationStrategy },
    { provide: HTTP_INTERCEPTORS, useClass: HttpErrorInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: AcceptLanguageInterceptor, multi: true },
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
    { provide: LOCALE_ID, useValue: setActiveLang() },
    provideHttpClient(withInterceptorsFromDi()),
    provideAnimations(),
    provideToastr({
      preventDuplicates: true,
    }),
  ],
})
  .catch(err => console.error(err));
