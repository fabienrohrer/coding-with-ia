import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA, Pipe, PipeTransform } from '@angular/core';
import { APP_BASE_HREF, Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { AppComponent } from './app.component';
import {
    TranslateLoader,
    TranslateModule,
    TranslateService,
    TranslationObject,
} from '@ngx-translate/core';
import { Router, RouterModule } from '@angular/router';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { UserService } from './security/user.service';
import { Observable, of } from 'rxjs';

class FakeTranslateLoader implements TranslateLoader {
    getTranslation(): Observable<TranslationObject> {
        return of({});
    }
}

describe('AppComponent', () => {
    beforeEach(async () => {
        TestBed.configureTestingModule({
            schemas: [NO_ERRORS_SCHEMA],
            imports: [
                RouterModule.forRoot([]),
                TranslateModule.forRoot({
                    loader: {
                        provide: TranslateLoader,
                        useClass: FakeTranslateLoader,
                    },
                }),
                ToastrModule.forRoot(),
                AppComponent,
            ],
            providers: [
                Location,
                { provide: LocationStrategy, useClass: PathLocationStrategy },
                { provide: APP_BASE_HREF, useValue: '/' },
                { provide: ToastrService },
                provideHttpClient(),
                provideHttpClientTesting(),
                UserService,
            ],
        });
        await TestBed.compileComponents();
    });

    it('should create the app', async () => {
        const fixture = TestBed.createComponent(AppComponent);
        const app = (await fixture.debugElement.componentInstance) as AppComponent;
        expect(app).toBeTruthy();
    });
});

/**
 * Global mock for the TranslateService
 */
export const translateServiceMock = (): TranslateService =>
    jasmine.createSpyObj<TranslateService>('TranslateService', {
        instant: 'translated',
        get: of('translated'),
    });

/**
 * Global mock for the TranslatePipe
 */
@Pipe({
    name: 'translate',
})
export class TranslatePipeMock implements PipeTransform {
    public transform(query: string): unknown {
        return query;
    }
}

/**
 * Global mock for the Router
 */
export const routerMock = (): Router =>
    jasmine.createSpyObj<Router>('Router', {
        navigate: undefined,
    });
