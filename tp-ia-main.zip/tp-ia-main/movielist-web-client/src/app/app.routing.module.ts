import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './security/containers/login/login.component';
import { HomeComponent } from './home/home.component';
import { CountryListComponent } from './sample-country/containers/country-list/country-list.component';

const routes: Routes = [
    { path: '', redirectTo: 'ui/home', pathMatch: 'full' },
    {
        path: 'ui',
        children: [
            { path: 'home', component: HomeComponent },
            { path: 'login', component: LoginComponent },
            { path: 'country', component: CountryListComponent },
            { path: '**', redirectTo: '' },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: false })],
    exports: [RouterModule],
})
export class AppRoutingModule {}
