import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { CountryListComponent } from './containers/country-list/country-list.component';
import { CountryDetailComponent } from './containers/country-detail/country-detail.component';
import { CountryFormComponent } from './components/country-form/country-form.component';
import { CountryService } from './services/country.service';
import { authGuard } from '../security/auth-guard';

const routes: Routes = [
    {
        path: 'ui',
        children: [
            {
                path: 'countries',
                canActivate: [authGuard],
                data: { roles: ['SCOPE_ADMIN', 'SCOPE_GUEST'] },
                children: [
                    { path: '', component: CountryListComponent },
                    { path: ':id', component: CountryDetailComponent },
                ],
            },
        ],
    },
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    TranslateModule.forChild(),
    CountryListComponent,
    CountryDetailComponent,
    CountryFormComponent,
  ],
  providers: [
    CountryService,
  ],
})
export class SampleCountryModule {}
