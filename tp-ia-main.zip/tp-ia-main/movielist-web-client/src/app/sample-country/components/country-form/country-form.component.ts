import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Country } from '../../models/country.interface';
import { ValidationError } from '../../../error/models/validation-error.interface';
import { FormsModule } from '@angular/forms';
import { NgClass } from '@angular/common';
import { TranslateDirective, TranslatePipe } from '@ngx-translate/core';
import { FieldFilter } from '../../../error/pipes/field-filter.pipe';

@Component({
    selector: 'movielist-sample-country-form',
    templateUrl: 'country-form.component.html',
    imports: [
        FormsModule,
        NgClass,
        TranslateDirective,
        FieldFilter,
        TranslatePipe,
    ],
})
export class CountryFormComponent {
    @Input()
    country?: Country;

    @Input()
    errors: ValidationError[] = [];

    @Output()
    save: EventEmitter<Country> = new EventEmitter<Country>();

    handleSubmit(value: Country): void {
        this.save.emit(value);
    }
}
