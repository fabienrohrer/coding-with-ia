import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CountryListComponent } from './country-list.component';
import { RouterModule } from '@angular/router';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import { CountryService } from '../../services/country.service';
import { Country } from '../../models/country.interface';
import { of } from 'rxjs';
import { TranslateDirective } from '@ngx-translate/core';
import { MockDirective } from 'ng-mocks';

describe('CountryListComponent', () => {
    let component: CountryListComponent;
    let fixture: ComponentFixture<CountryListComponent>;
    let countryService: jasmine.SpyObj<CountryService>;

    beforeEach(async () => {
        countryService = jasmine.createSpyObj<CountryService>('CountryService', [
            'getCountries',
            'deleteCountry',
        ]);
        countryService.getCountries.and.returnValue(of());
        countryService.deleteCountry.and.returnValue(of());
        TestBed.configureTestingModule({
            schemas: [NO_ERRORS_SCHEMA],
            imports: [
                RouterModule.forRoot([]),
                CountryListComponent,
                MockDirective(TranslateDirective),
            ],
            providers: [
                { provide: APP_BASE_HREF, useValue: '/' },
                { provide: CountryService, useValue: countryService },
            ],
        });
        await TestBed.compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(CountryListComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create the component', () => {
        expect(component).toBeTruthy();
    });

    it('should delete the country', () => {
        component.delete({ id: 1, name: 'Switzerland' } as Country);
        expect(countryService.deleteCountry).toHaveBeenCalledTimes(1);
    });
});
