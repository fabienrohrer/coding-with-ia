import { Component, OnInit } from '@angular/core';
import { Country } from '../../models/country.interface';
import { CountryService } from '../../services/country.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ValidationError } from '../../../error/models/validation-error.interface';
import { HttpErrorResponse } from '@angular/common/http';
import { HttpErrorInterceptor } from '../../../security/http-error-interceptor';
import { Problem } from '../../../error/models/problem.interface';
import { TranslateDirective } from '@ngx-translate/core';
import { CountryFormComponent } from '../../components/country-form/country-form.component';

@Component({
    selector: 'movielist-sample-country-detail',
    templateUrl: 'country-detail.component.html',
    imports: [TranslateDirective, CountryFormComponent],
})
export class CountryDetailComponent implements OnInit {
    country?: Country;
    errors: ValidationError[] = [];

    constructor(
        private activatedRoute: ActivatedRoute,
        private router: Router,
        private countryService: CountryService,
    ) {}

    ngOnInit(): void {
        this.activatedRoute.params.subscribe((params: Params) => {
            const id = params['id'] as number;
            if (!isNaN(id)) {
                this.countryService.getCountry(+id).subscribe((data: Country) => {
                    console.log('Received', data);
                    this.country = data;
                });
            }
        });
    }

    handleSave(submittedCountry: Country): void {
        if (this.country?.id) {
            submittedCountry.id = this.country.id;
            this.countryService.updateCountry(submittedCountry).subscribe({
                next: data => {
                    console.log('Updated country', data);
                    void this.router.navigate(['/ui/countries']);
                },
                error: (response: HttpErrorResponse) => {
                    this.errors = HttpErrorInterceptor.isResponseAProblem(response.error)
                        ? (response.error as Problem).validationErrors
                        : [];
                },
            });
        } else {
            this.countryService.createCountry(submittedCountry).subscribe({
                next: data => {
                    console.log('Created country', data);
                    void this.router.navigate(['/ui/countries']);
                },
                error: (response: HttpErrorResponse) => {
                    this.errors = HttpErrorInterceptor.isResponseAProblem(response.error)
                        ? (response.error as Problem).validationErrors
                        : [];
                },
            });
        }
    }
}
