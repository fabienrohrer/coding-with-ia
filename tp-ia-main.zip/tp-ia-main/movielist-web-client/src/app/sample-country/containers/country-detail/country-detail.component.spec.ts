import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CountryDetailComponent } from './country-detail.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ActivatedRoute, Params, Router, RouterModule } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';
import { of, Subject } from 'rxjs';
import { CountryService } from '../../services/country.service';
import { Country } from '../../models/country.interface';
import { routerMock } from '../../../app.component.spec';
import { TranslateDirective } from '@ngx-translate/core';
import { CountryFormComponent } from '../../components/country-form/country-form.component';
import { MockComponent, MockDirective } from 'ng-mocks';

describe('CountryDetailComponent', () => {
    let countryService: jasmine.SpyObj<CountryService>;
    let component: CountryDetailComponent;
    let fixture: ComponentFixture<CountryDetailComponent>;
    let routeParams: Subject<Params>;
    const expectedCountry: Country = {
        id: 1,
        name: 'Switzerland',
    };

    beforeEach(async () => {
        routeParams = new Subject<Params>();
        countryService = jasmine.createSpyObj<CountryService>('CountryService', [
            'getCountry',
            'createCountry',
            'updateCountry',
        ]);
        countryService.createCountry.and.returnValue(of(expectedCountry));
        countryService.getCountry.and.returnValue(of(expectedCountry));
        countryService.updateCountry.and.returnValue(of());
        TestBed.configureTestingModule({
            schemas: [NO_ERRORS_SCHEMA],
            imports: [
              RouterModule,
              CountryDetailComponent,
              MockDirective(TranslateDirective),
              MockComponent(CountryFormComponent),
            ],
            providers: [
                { provide: APP_BASE_HREF, useValue: '/' },
                { provide: ActivatedRoute, useValue: { params: routeParams } },
                { provide: CountryService, useValue: countryService },
                { provide: Router, useValue: routerMock() },
            ],
        });
        await TestBed.compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(CountryDetailComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create the component', () => {
        expect(component).toBeTruthy();
    });

    it('should check if the country is loaded from giving router param id', () => {
        routeParams.next({ id: 1 });
        expect(component.country?.name).toEqual(expectedCountry.name);
    });

    it('should create a new country', () => {
        routeParams.next({ id: 'new' });
        component.handleSave({ id: 42, name: 'Swaziland' } as Country);
        expect(countryService.createCountry).toHaveBeenCalledTimes(1);
    });

    it('should update the country', () => {
        routeParams.next({ id: 1 });
        component.handleSave({ id: 43, name: 'Italy' } as Country);
        expect(countryService.updateCountry).toHaveBeenCalledTimes(1);
    });
});
