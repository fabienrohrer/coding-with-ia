/**
 * Casts a value to a type without checking if the value is of that type.
 * Should be used scarcely, e.g. in test to check for wrong/unexpected input
 * or when some external typing is bugged.
 * @param value Value to cast
 * @returns Same value, with the type casted to the type of the generic parameter
 */
export function castUnsafe<T>(value: unknown): T {
    return value as T;
}
