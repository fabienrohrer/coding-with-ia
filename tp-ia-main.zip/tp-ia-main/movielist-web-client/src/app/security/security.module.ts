import { NgModule } from '@angular/core';
import { LoginComponent } from './containers/login/login.component';
import { UserService } from './user.service';
import { TranslateModule } from '@ngx-translate/core';
import { GlobalErrorHandler } from '../error/services/global-error-handler.service';

@NgModule({
  imports: [
    TranslateModule.forChild(),
    LoginComponent,
  ],
  providers: [
    UserService,
    GlobalErrorHandler,
  ],
})
export class SecurityModule {}
