import { inject } from '@angular/core';
import { ActivatedRouteSnapshot } from '@angular/router';
import { UserService } from './user.service';

export const authGuard = (route: ActivatedRouteSnapshot) => {
    const userService = inject(UserService);
    const neededRoles = route.data['roles'] as Array<string>;
    return userService.canActivate(neededRoles);
};
