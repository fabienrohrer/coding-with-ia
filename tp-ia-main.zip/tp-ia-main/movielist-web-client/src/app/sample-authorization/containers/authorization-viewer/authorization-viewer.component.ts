import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../security/user.service';
import { User } from '../../../security/user.interface';
import { TranslateDirective } from '@ngx-translate/core';

@Component({
    selector: 'movielist-sample-authorization-viewer',
    templateUrl: 'authorization-viewer.component.html',
    imports: [TranslateDirective],
})
export class AuthorizationViewerComponent implements OnInit {
    isLoggedIn = false;
    user: User | null = null;

    constructor(private userService: UserService) {}

    ngOnInit(): void {
        this.userService.getCurrentUserFromServer().subscribe({
            next: (user: User) => {
                this.user = user;
                this.isLoggedIn = !!user;
            },
            error: error => {
                console.error("Couldn't load user", error);
                this.user = null;
                this.isLoggedIn = false;
            },
        });
    }
}
