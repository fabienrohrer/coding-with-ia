import { Component, Inject, LOCALE_ID, OnInit } from '@angular/core';
import { DOCUMENT, NgClass, NgIf, UpperCasePipe } from '@angular/common';
import { TranslateService, TranslatePipe } from '@ngx-translate/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { UserService } from './security/user.service';

@Component({
    selector: 'movielist-root',
    templateUrl: 'app.component.html',
    imports: [
        NgClass,
        NgIf,
        RouterLink,
        RouterLinkActive,
        TranslatePipe,
        UpperCasePipe,
        RouterOutlet,
    ],
})
export class AppComponent implements OnInit {
    constructor(
        @Inject(LOCALE_ID) public language: 'de' | 'fr' | 'it' | 'en',
        private translateService: TranslateService,
        private router: Router,
        public userService: UserService,
        @Inject(DOCUMENT) public document: Document,
    ) {}

    public ngOnInit(): void {
          this.translateService.use(this.language);
    }

    public switchLanguage(lang: 'de' | 'fr' | 'it' | 'en', event: Event): void {
        event.preventDefault();
        this.language = lang;
        this.translateService.use(lang);
    }

    public logout(event: Event): void {
        event.preventDefault();
        this.userService.logout();
    }
}
